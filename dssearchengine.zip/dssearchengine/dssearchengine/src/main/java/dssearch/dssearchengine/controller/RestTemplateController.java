package dssearch.dssearchengine.controller;

public class RestTemplateController {


}
