package dssearch.dssearchengine.controller;

import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.Id;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import java.time.LocalDateTime;

@Getter @Setter
public class BloglistForm {

    @Id @GeneratedValue
    @Column(name="blog_id")
    private Long id;
    private String title;
    private String contents;
    private String url;
    private String blogname;
    private String thumbnail;
    private LocalDateTime datetime;
}
}
