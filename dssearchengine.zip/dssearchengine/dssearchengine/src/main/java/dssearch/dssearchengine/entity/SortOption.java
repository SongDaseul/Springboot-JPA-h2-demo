package dssearch.dssearchengine.entity;

public enum SortOption {
    accuracy,recency
}
