package dssearch.dssearchengine.controller;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotEmpty;

@Getter @Setter
public class SearchForm {

    @NotEmpty(message = "검색어는 필수 입니다.")
    private String keyword;
    private String sortoption;
}
