package dssearch.dssearchengine.entity;

import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.Entity;
import org.springframework.data.annotation.Id;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;

@Entity
@Getter @Setter
public class Rank {
    @Id @GeneratedValue
    @Column(name="rank_id")
    private String id;

    private String keyword;

    private int count;
}
