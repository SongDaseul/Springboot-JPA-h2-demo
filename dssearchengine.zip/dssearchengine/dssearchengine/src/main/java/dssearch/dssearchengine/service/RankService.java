package dssearch.dssearchengine.service;

import dssearch.dssearchengine.entity.Rank;
import dssearch.dssearchengine.repository.RankRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class RankService {

    private final RankRepository rankRepository;

    public void save(Rank rank){
        rankRepository.save(rank);
    }

    public Rank findByName(String keyword){
        return rankRepository.findByName(keyword);
    }

    public List<Rank> findAll(){
        return rankRepository.findAll();
    }
}
