package dssearch.dssearchengine.repository;

import dssearch.dssearchengine.entity.Rank;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.List;

@Repository
@RequiredArgsConstructor
public class RankRepository {

    private final EntityManager em;

    public void save(Rank rank){
        if(rank.getId() == null){
            em.persist(rank);
        }else{

        }
    }

    public Rank findByName(String keyword){
        return em.createQuery("select r from Rank r where r.keyword = :keyword",Rank.class)
                .setParameter("keyword",keyword)
                .getSingleResult();
    }

    public List<Rank> findAll(){
        return em.createQuery("select r from Rank r order by count desc", Rank.class)
                .getResultList();
    }

}
